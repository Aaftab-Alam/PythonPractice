import json
from flask import session

print(dir(session))
